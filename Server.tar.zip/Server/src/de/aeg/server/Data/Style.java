package de.aeg.server.Data;

public enum Style {

	a,b,c
	
}
